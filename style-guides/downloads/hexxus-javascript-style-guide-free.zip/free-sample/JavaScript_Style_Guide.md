# JavaScript Style Guide

## Overview

This guide establishes standards for writing clean, maintainable vanilla JavaScript for web browsers. It covers naming conventions, function declarations, DOM manipulation, event handling, async patterns, error handling, and performance considerations.

> **This guide covers vanilla JavaScript only** (no frameworks). For related guides, see:
> - [HTML Style Guide](./HTML_Style_Guide.md) — Document structure and semantic markup
> - [CSS Style Guide](./CSS_Style_Guide.md) — Styling and layout
> - [HTML/CSS/JS Integration Guide](./HTML_CSS_JS_Style_Guide.md) — Using all three together in a project
> - [React Style Guide](./React_Style_Guide.md) — React component conventions (extends this guide)

> [!NOTE]
> **TypeScript is not used in this project.** All files use plain `.js`. If TypeScript adoption becomes necessary in the future, a dedicated TypeScript style guide will be created at that time.

**Core Principles:**
1. **Clarity over brevity**: Write code that's easy to understand and maintain
2. **Native over libraries**: Prefer built-in browser APIs over external dependencies
3. **Explicit over implicit**: Make intentions clear — avoid clever tricks
4. **Security by default**: Escape user input, avoid `eval`, never trust external data
5. **Fail loudly**: Handle errors explicitly; don't let failures silently pass

---

## Table of Contents

1. [File Naming](#file-naming)
2. [Code Organization](#code-organization)
3. [Naming Conventions](#naming-conventions)
4. [Variable Declarations](#variable-declarations)
5. [Function Declarations](#function-declarations)
6. [DOM Manipulation](#dom-manipulation)
7. [Event Handling](#event-handling)
8. [Async and Promises](#async-and-promises)
9. [Error Handling](#error-handling)
10. [Comments and Documentation](#comments-and-documentation)
11. [Performance](#performance)
12. [Security](#security)
13. [Testing and Validation](#testing-and-validation)
14. [Common Utilities](#common-utilities)
15. [Quick Reference](#quick-reference)
16. [Resources](#resources)

---

## File Naming

**Use camelCase for JavaScript files:**

```
✅ main.js
✅ formValidation.js
✅ imageSlider.js
✅ apiClient.js

❌ main-script.js
❌ form_validation.js
❌ FormValidation.js
```

---

## Code Organization

### File Structure

Organize every JavaScript file in this order:

```javascript
'use strict';

/******************************************************************************
 * Constants
 ******************************************************************************/

const API_BASE_URL = 'https://api.example.com';
const DEBOUNCE_DELAY = 300;
const MAX_FILE_SIZE = 5242880; // 5MB in bytes

/******************************************************************************
 * State
 ******************************************************************************/

const appState = {
  isAuthenticated: false,
  currentUser: null,
  items: [],
};

/******************************************************************************
 * Utility Functions
 ******************************************************************************/

const debounce = (func, delay) => {
  let timeoutId;
  return (...args) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func(...args), delay);
  };
};

/******************************************************************************
 * DOM Helpers
 ******************************************************************************/

const get_element = (selector) => document.querySelector(selector);
const get_all_elements = (selector) => Array.from(document.querySelectorAll(selector));

/******************************************************************************
 * API Functions
 ******************************************************************************/

const fetch_users = async () => {
  // ...
};

/******************************************************************************
 * Event Handlers
 ******************************************************************************/

const handle_form_submit = (event) => {
  // ...
};

/******************************************************************************
 * Initialization
 ******************************************************************************/

const initialize = () => {
  setup_event_listeners();
};

document.addEventListener('DOMContentLoaded', initialize);
```

### `'use strict'`

Begin every JavaScript file with `'use strict'`. This catches common mistakes and prevents silent errors:

```javascript
// ✅ GOOD - First line of every file
'use strict';

const my_function = () => { /* ... */ };
```

---

## Naming Conventions

### Variables

**Use `camelCase` for all variables, function parameters, and object properties:**

```javascript
// ✅ GOOD
const userData = fetchUserData();
const isAuthenticated = true;
const pageNumber = 1;
const userPreferences = { theme: 'dark' };

// ❌ BAD
const UserData = fetchUserData();
const is_authenticated = true;
const PageNumber = 1;
```

### Constants

**Use `SCREAMING_SNAKE_CASE` for constants:**

```javascript
// ✅ GOOD
const MAX_RETRY_ATTEMPTS = 3;
const API_BASE_URL = 'https://api.example.com';
const DEFAULT_PAGE_SIZE = 20;

const HTTP_STATUS = {
  OK: 200,
  NOT_FOUND: 404,
  SERVER_ERROR: 500,
};

// ❌ BAD
const maxRetryAttempts = 3;
const apiBaseUrl = 'https://api.example.com';
const defaultPageSize = 20;
```

**When is something a constant?**
- Value never changes during runtime
- Represents configuration or magic numbers
- Used across multiple files
- Defines an enumeration or set of options

### Functions

**Use `snake_case` for function names:**

```javascript
// ✅ GOOD
const fetch_user_data = async (userId) => { /* ... */ };
const calculate_total_price = (items) => { /* ... */ };
const format_date_string = (date) => { /* ... */ };

// ❌ BAD
const fetchUserData = async (userId) => { /* ... */ };
const calculateTotalPrice = (items) => { /* ... */ };
const formatDateString = (date) => { /* ... */ };
```

### Event Handlers

**Prefix event handler functions with `handle_`:**

```javascript
// ✅ GOOD
const handle_submit = (event) => { /* ... */ };
const handle_input_change = (event) => { /* ... */ };
const handle_scroll = () => { /* ... */ };

// ❌ BAD
const onSubmit = (event) => { /* ... */ };
const submitForm = (event) => { /* ... */ };
const onChange = (event) => { /* ... */ };
```

### Classes

**Use `PascalCase` for classes and constructors:**

```javascript
// ✅ GOOD
class UserProfile {
  constructor(name, email) {
    this.name = name;
    this.email = email;
  }
}

class ApiClient {
  // ...
}

// ❌ BAD
class userProfile { }
class api_client { }
```

---

## Variable Declarations

**Use `const` by default. Use `let` only when reassignment is needed. Never use `var`:**

```javascript
// ✅ GOOD
const API_URL = 'https://api.example.com';
const userData = { name: 'John' };
let counter = 0;
counter += 1;

// ❌ BAD
var API_URL = 'https://api.example.com';
var userData = { name: 'John' };
var counter = 0;
```

### Destructuring

Use destructuring for objects and arrays:

```javascript
// ✅ GOOD - Object destructuring
const { name, email, role } = user;
const { data, error } = await fetch_user();

// ✅ GOOD - Array destructuring
const [first, second, ...rest] = items;

// ✅ GOOD - Destructuring with rename
const { name: userName, id: userId } = user;

// ✅ GOOD - Default values in destructuring
const { name = 'Anonymous', role = 'guest' } = user;

// ❌ BAD
const name = user.name;
const email = user.email;
const role = user.role;
```

### Template Literals

Use template literals for string interpolation:

```javascript
// ✅ GOOD
const greeting = `Hello, ${userName}!`;
const url = `/api/users/${userId}/posts`;
const message = `User ${name} has ${count} items`;

// ❌ BAD
const greeting = 'Hello, ' + userName + '!';
const url = '/api/users/' + userId + '/posts';
```

### Object Property Shorthand

Use shorthand when property name matches variable name:

```javascript
// ✅ GOOD
const name = 'John';
const age = 30;
const user = { name, age, role: 'admin' };

// ❌ BAD
const user = { name: name, age: age, role: 'admin' };
```

### Optional Chaining and Nullish Coalescing

```javascript
// ✅ GOOD - Optional chaining for safe property access
const city = user?.address?.city;
const firstItem = items?.[0];
const result = fetchData?.();

// ✅ GOOD - Nullish coalescing for default values
const pageSize = userPageSize ?? DEFAULT_PAGE_SIZE;
const userName = user.name ?? 'Anonymous';

// ❌ BAD - Does not handle 0 or '' correctly
const pageSize = userPageSize || DEFAULT_PAGE_SIZE;
```

### Array Methods

Prefer array methods over imperative loops:

```javascript
// ✅ GOOD
const activeUsers = users.filter(user => user.isActive);
const userNames = users.map(user => user.name);
const hasAdmin = users.some(user => user.role === 'admin');
const totalAge = users.reduce((sum, user) => sum + user.age, 0);

// ❌ BAD
const activeUsers = [];
for (let i = 0; i < users.length; i++) {
  if (users[i].isActive) {
    activeUsers.push(users[i]);
  }
}
```

---

## Function Declarations

### Arrow Functions as Constants (Default)

**Declare functions as `const` using arrow function syntax:**

```javascript
// ✅ GOOD - Default approach
const calculate_total = (items) => {
  return items.reduce((sum, item) => sum + item.price, 0);
};

// ✅ GOOD - Implicit return for simple functions
const double = (x) => x * 2;
const get_name = (user) => user.name;
const is_active = (item) => item.status === 'active';

// ❌ BAD - Avoid function declarations by default
function calculate_total(items) {
  return items.reduce((sum, item) => sum + item.price, 0);
}
```

### When to Use Function Declarations

You may use traditional `function` declarations for:
1. **Simple, self-contained utility functions**
2. **Functions that need hoisting**
3. **Recursive functions** (clearer syntax)
4. **Top-level module functions** (in some cases)

**CRITICAL**: Always include a comment explaining why you're using a function declaration.

```javascript
// ✅ GOOD - Exception with explanation
// Using function declaration for hoisting - called before definition in setup sequence
function initialize_app() {
  setup_event_listeners();
  load_initial_data();
}

// Using function declaration for clarity in recursive case
function traverse_tree(node) {
  if (!node) return;
  process_node(node);
  node.children.forEach(child => traverse_tree(child));
}

// ❌ BAD - Exception without explanation
function calculate_price(items) {
  return items.reduce((sum, item) => sum + item.price, 0);
}
```

### Implicit Returns

For simple arrow functions, use implicit returns when possible:

```javascript
// ✅ GOOD - Simple transformation
const double = (x) => x * 2;
const get_name = (user) => user.name;
const is_active = (item) => item.status === 'active';

// ✅ ALSO GOOD - Explicit return for clarity in multi-step logic
const calculate_discount = (price, discountRate) => {
  return price * (1 - discountRate);
};

// ❌ BAD - Unnecessary braces and return for simple operations
const double = (x) => {
  return x * 2;
};
```

### Async Functions

Always use async arrow functions for asynchronous operations:

```javascript
// ✅ GOOD
const fetch_user_data = async (userId) => {
  try {
    const response = await fetch(`/api/users/${userId}`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Failed to fetch user:', error);
    throw error;
  }
};

// ❌ BAD
async function fetch_user_data(userId) {
  // ...
}
```

---

## DOM Manipulation

### Cache DOM Queries

Never query the DOM repeatedly for the same element:

```javascript
// ❌ BAD - Querying DOM on every call
const update_ui = () => {
  document.querySelector('.counter').textContent = count;
  document.querySelector('.counter').classList.add('updated');
  document.querySelector('.counter').style.color = 'blue';
};

// ✅ GOOD - Cache the element
const update_ui = () => {
  const counter = document.querySelector('.counter');
  counter.textContent = count;
  counter.classList.add('updated');
  counter.style.color = 'blue';
};

// ✅ EVEN BETTER - Cache once at initialization
let counterElement;

const initialize = () => {
  counterElement = document.querySelector('.counter');
};

const update_ui = () => {
  counterElement.textContent = count;
};
```

### Use Modern DOM Methods

```javascript
// ✅ GOOD - Modern methods
const element = document.querySelector('.item');
const elements = document.querySelectorAll('.item');
element.classList.add('active');
element.classList.remove('hidden');
element.classList.toggle('expanded');
element.classList.contains('active');

// ❌ BAD - Old methods
const element = document.getElementsByClassName('item')[0];
element.className += ' active';  // Could duplicate class names
```

### Creating Elements

```javascript
// ✅ GOOD - Create and populate with DOM API
const create_card = (data) => {
  const card = document.createElement('div');
  card.className = 'card';

  const title = document.createElement('h3');
  title.className = 'card__title';
  title.textContent = data.title;  // textContent prevents XSS

  const description = document.createElement('p');
  description.className = 'card__description';
  description.textContent = data.description;

  card.appendChild(title);
  card.appendChild(description);

  return card;
};

// ✅ ALSO GOOD - Template literal for complex HTML (must escape user data)
const create_card = (data) => {
  const container = document.createElement('div');
  container.innerHTML = `
    <div class="card">
      <h3 class="card__title">${escape_html(data.title)}</h3>
      <p class="card__description">${escape_html(data.description)}</p>
    </div>
  `.trim();
  return container.firstElementChild;
};

// ✅ GOOD - Batch DOM insertions with DocumentFragment
const render_items = (items) => {
  const fragment = document.createDocumentFragment();

  items.forEach(item => {
    const element = document.createElement('li');
    element.textContent = item.name;
    fragment.appendChild(element);
  });

  list.appendChild(fragment); // Single reflow
};
```

---

## Event Handling

### Event Delegation

Use event delegation for dynamic content instead of attaching listeners to individual elements:

```javascript
// ❌ BAD - Attaching to individual elements (breaks with dynamic content)
document.querySelectorAll('.delete-btn').forEach(btn => {
  btn.addEventListener('click', handle_delete);
});

// ✅ GOOD - Event delegation
document.querySelector('.item-list').addEventListener('click', (event) => {
  if (event.target.matches('.delete-btn')) {
    handle_delete(event);
  }
  if (event.target.matches('.edit-btn')) {
    handle_edit(event);
  }
});

// ✅ GOOD - Reusable delegate helper
const delegate = (parent, selector, eventType, handler) => {
  parent.addEventListener(eventType, (event) => {
    const target = event.target.closest(selector);
    if (target && parent.contains(target)) {
      handler(event, target);
    }
  });
};

// Usage
delegate(document.querySelector('.item-list'), '.delete-btn', 'click', handle_delete);
```

### Adding and Removing Listeners

```javascript
// ✅ GOOD - Named function reference allows removal
const handle_close = () => {
  modal.classList.remove('is-open');
  closeBtn.removeEventListener('click', handle_close);
};

const open_modal = () => {
  modal.classList.add('is-open');
  closeBtn.addEventListener('click', handle_close);
};
```

### Common Events

```javascript
// Page ready
document.addEventListener('DOMContentLoaded', initialize);

// Form submission
form.addEventListener('submit', (event) => {
  event.preventDefault();
  handle_submit(event);
});

// Keyboard
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') close_modal();
  if (event.key === 'Enter') confirm_action();
});

// Click outside
document.addEventListener('click', (event) => {
  if (!dropdown.contains(event.target)) {
    close_dropdown();
  }
});
```

---

## Async and Promises

### Prefer async/await Over Promise Chains

```javascript
// ✅ GOOD - async/await
const load_user_data = async (userId) => {
  try {
    const response = await fetch(`/api/users/${userId}`);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const user = await response.json();
    return user;
  } catch (error) {
    console.error('Error loading user:', error);
    show_error_message('Failed to load user data');
    throw error;
  }
};

// ❌ BAD - Promise chains (harder to read and handle errors)
const load_user_data = (userId) => {
  return fetch(`/api/users/${userId}`)
    .then(response => {
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return response.json();
    })
    .then(user => user)
    .catch(error => {
      console.error('Error loading user:', error);
      throw error;
    });
};
```

### Parallel vs. Sequential

```javascript
// ✅ GOOD - Parallel (when requests are independent)
const load_dashboard_data = async () => {
  const [users, posts, comments] = await Promise.all([
    fetch_users(),
    fetch_posts(),
    fetch_comments(),
  ]);

  return { users, posts, comments };
};

// ✅ GOOD - Sequential (when order matters)
const process_user_workflow = async (userId) => {
  const user = await fetch_user(userId);
  const preferences = await fetch_user_preferences(user.id);
  const updated = await update_user_settings(user.id, preferences);
  return updated;
};

// ❌ BAD - Sequential when parallel would work
const load_dashboard_data = async () => {
  const users = await fetch_users();
  const posts = await fetch_posts();      // Waits unnecessarily for users
  const comments = await fetch_comments(); // Waits unnecessarily for posts
  return { users, posts, comments };
};
```

---

## Error Handling

### Always Handle Errors Explicitly

```javascript
// ✅ GOOD - Specific error handling
const submit_form = async (formData) => {
  try {
    validate_form_data(formData);

    const response = await fetch('/api/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Submission failed');
    }

    const result = await response.json();
    show_success_message('Form submitted successfully!');
    return result;

  } catch (error) {
    if (error.name === 'ValidationError') {
      show_validation_errors(error.details);
    } else if (error.name === 'TypeError') {
      show_error_message('Network error. Please check your connection.');
    } else {
      show_error_message('An unexpected error occurred.');
      console.error('Form submission error:', error);
    }
    throw error;
  }
};
```

### Custom Error Classes

```javascript
// ✅ GOOD - Custom error classes for specific failure modes
class ValidationError extends Error {
  constructor(message, details = []) {
    super(message);
    this.name = 'ValidationError';
    this.details = details;
  }
}

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

// Usage
const validate_form_data = (data) => {
  const errors = [];

  if (!data.email) errors.push({ field: 'email', message: 'Required' });
  if (!data.password) errors.push({ field: 'password', message: 'Required' });

  if (errors.length > 0) {
    throw new ValidationError('Form validation failed', errors);
  }
};
```

---

## Comments and Documentation

### Comment Why, Not What

```javascript
// ✅ GOOD - Explains WHY
// Using function declaration here instead of arrow function because
// this function needs to be hoisted for the initialization sequence
function initialize_app() {
  // ...
}

// Premium users get 20% off; standard users get 10%
// Rates defined in the product pricing meeting (2025-01-15)
const discountRate = userLevel === 'premium' ? 0.20 : 0.10;

// ❌ BAD - States the obvious
// Set the user name to the name from the response
const userName = response.data.name;

// Increment counter by 1
counter++;
```

### JSDoc for Public APIs

Use JSDoc for exported functions, especially in services and utilities:

```javascript
/**
 * Calculates the total price including tax and discount
 * @param {number} basePrice - The base price before any calculations
 * @param {number} taxRate - Tax rate as decimal (e.g., 0.08 for 8%)
 * @param {number} discountPercent - Discount as percentage (e.g., 10 for 10%)
 * @returns {number} Final price after tax and discount
 */
export const calculate_final_price = (basePrice, taxRate, discountPercent) => {
  const discountAmount = basePrice * (discountPercent / 100);
  const discountedPrice = basePrice - discountAmount;
  return discountedPrice * (1 + taxRate);
};
```

### TODO Comments

```javascript
// TODO: Add pagination support
// TODO: [Priority] Fix race condition in data fetching
// TODO: (James, 2025-02-06) Optimize this query before launch
// FIXME: This breaks when userName contains special characters
// HACK: Temporary workaround until browser bug is fixed (Chrome < 120)
```

---

## Performance

### Debounce and Throttle

```javascript
// Debounce - Execute after user stops triggering
const debounce = (func, delay) => {
  let timeoutId;
  return (...args) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func(...args), delay);
  };
};

// Usage: Search as user types
const search_input = document.querySelector('#search');
const perform_search = debounce((query) => {
  fetch_search_results(query);
}, 300);

search_input.addEventListener('input', (event) => {
  perform_search(event.target.value);
});

// Throttle - Execute at most once per interval
const throttle = (func, limit) => {
  let inThrottle;
  return (...args) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => { inThrottle = false; }, limit);
    }
  };
};

// Usage: Scroll event
window.addEventListener('scroll', throttle(() => {
  update_scroll_indicator();
}, 100));
```

### Avoid Layout Thrashing

Read layout properties and write style changes separately:

```javascript
// ❌ BAD - Forces synchronous layout recalculation on each iteration
elements.forEach(el => {
  const height = el.offsetHeight;  // Read
  el.style.height = `${height * 2}px`;  // Write (triggers reflow)
});

// ✅ GOOD - Batch reads, then batch writes
const heights = elements.map(el => el.offsetHeight);  // All reads
elements.forEach((el, i) => {
  el.style.height = `${heights[i] * 2}px`;  // All writes
});
```

### Use CSS for Animations

```javascript
// ❌ BAD - JavaScript animation (causes reflow)
const animate = () => {
  element.style.left = `${parseFloat(element.style.left) + 1}px`;
  requestAnimationFrame(animate);
};

// ✅ GOOD - Use CSS transforms (GPU-accelerated, no reflow)
element.classList.add('is-moving');
// CSS: .is-moving { transform: translateX(100px); transition: transform 0.3s; }
```

---

## Security

### Always Escape User Input

**Never insert user-controlled data directly into HTML:**

```javascript
// ❌ VERY BAD - XSS vulnerability
element.innerHTML = `<p>Hello, ${userName}!</p>`;
element.innerHTML = userInput;

// ✅ GOOD - Use textContent (always safe)
element.textContent = userName;

// ✅ GOOD - Escape function when innerHTML is required
const escape_html = (unsafe) => {
  return String(unsafe)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
};

element.innerHTML = `<p>Hello, ${escape_html(userName)}!</p>`;
```

### Never Use `eval()`

```javascript
// ❌ NEVER - eval is a security vulnerability
eval(userInput);
new Function(userInput)();

// ✅ GOOD - Use a safe dispatch table instead
const actions = {
  'delete': handle_delete,
  'edit': handle_edit,
  'view': handle_view,
};
actions[actionName]?.();
```

### Validate URLs Before Navigation

```javascript
// ❌ BAD - Open redirect vulnerability
window.location.href = userProvidedUrl;

// ✅ GOOD - Validate URL before redirecting
const safe_redirect = (url) => {
  try {
    const parsed = new URL(url, window.location.origin);
    // Only allow same-origin redirects
    if (parsed.origin === window.location.origin) {
      window.location.href = parsed.href;
    }
  } catch {
    console.error('Invalid redirect URL:', url);
  }
};
```

---

## Testing and Validation

### Use ESLint

```json
{
  "env": {
    "browser": true,
    "es2021": true
  },
  "extends": "eslint:recommended",
  "parserOptions": {
    "ecmaVersion": 2021,
    "sourceType": "module"
  },
  "rules": {
    "indent": ["error", 2],
    "quotes": ["error", "single"],
    "semi": ["error", "always"],
    "no-unused-vars": "warn",
    "no-console": "off",
    "no-eval": "error"
  }
}
```

### Feature Detection

```javascript
// ✅ GOOD - Feature detection
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(handle_intersection);
  observer.observe(element);
} else {
  // Fallback behavior
  show_element_immediately();
}

// ❌ BAD - Browser detection
if (navigator.userAgent.includes('Chrome')) {
  // Browser detection is unreliable and excludes valid browsers
}
```

---

## Common Utilities

### Ready Helper

```javascript
const ready = (callback) => {
  if (document.readyState !== 'loading') {
    callback();
  } else {
    document.addEventListener('DOMContentLoaded', callback);
  }
};

ready(() => {
  initialize();
});
```

### Local Storage with Error Handling

```javascript
const storage = {
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Failed to save to localStorage:', error);
    }
  },

  get(key) {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Failed to read from localStorage:', error);
      return null;
    }
  },

  remove(key) {
    localStorage.removeItem(key);
  },
};
```

### URL Parameters

```javascript
const get_query_param = (name) => {
  const params = new URLSearchParams(window.location.search);
  return params.get(name);
};

const set_query_param = (name, value) => {
  const url = new URL(window.location.href);
  url.searchParams.set(name, value);
  history.pushState({}, '', url);
};
```

---

## Quick Reference

### Naming Summary

| Type | Convention | Example |
|------|-----------|---------|
| Variables | `camelCase` | `userName`, `isActive` |
| Constants | `SCREAMING_SNAKE_CASE` | `API_BASE_URL`, `MAX_RETRIES` |
| Functions | `snake_case` | `fetch_user_data()`, `calculate_total()` |
| Event handlers | `handle_` prefix | `handle_submit()`, `handle_click()` |
| Classes | `PascalCase` | `UserProfile`, `ApiClient` |

### Declaration Preference

```javascript
const preferred = 'always const';
let whenReassigned = 'use let';
// var - never use
```

### Async Pattern

```javascript
const do_something = async () => {
  try {
    const result = await some_async_call();
    return result;
  } catch (error) {
    handle_error(error);
    throw error; // re-throw if caller needs to know
  }
};
```

---

## Resources

- **MDN JavaScript Reference**: https://developer.mozilla.org/en-US/docs/Web/JavaScript
- **ESLint**: https://eslint.org/
- **JavaScript Info**: https://javascript.info/
- **OWASP XSS Prevention**: https://owasp.org/www-community/attacks/xss/
- **Can I Use**: https://caniuse.com/

---

## Version History

- v1.2.0 (2026-02-22): Added TypeScript policy note
- v1.1.0 (2026-02-22): Aligned with React Style Guide — 2-space indentation, full function declaration exceptions list, added object property shorthand, array methods, and "when is it a constant?" criteria
- v1.0.0 (2026-02-22): Extracted from HTML/CSS/JS Style Guide into standalone JavaScript guide

