# Free sample - the Hexxus JavaScript style guide

This is the full JavaScript guide from the Hexxus style guide collection,
free. No email gate, no watermark, no crippled version - the real file.

Point your AI coding assistant at it and compare the output before and
after. If the difference earns its keep, the full collection covers
HTML, CSS, the integration between all three layers, React, Python,
Bash, and Markdown:

- Web dev bundle (5 guides): $19
- Complete collection (12 guides): $39

https://hexxusweb.com/style-guides/

**Quick start with Claude Code** - add to your project's `CLAUDE.md`:

```markdown
Before writing any JavaScript, read and follow:
./JavaScript_Style_Guide.md
```

**Cursor:** point `.cursorrules` at the file, or paste the Quick
Reference section.

Personal and commercial use welcome. Redistribution isn't - send people
to the link above instead.

Questions: jstacy@hexxusweb.com
